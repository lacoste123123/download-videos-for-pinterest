RU:
Это расширение (PVD) позволяет скачивать видео с пинтерест (pinterest), обычно видео нельзя скачивать с сайта, ранее я пользовался всякими сайтами что бы скачать видео с пина, теперь я пользуюсь сам своим расширением😜
Иногда с первого раза не качает, нужно подождать 15 секунд либо сразу перезапустить сайт, возможно решу, если придумаю как.
Расширение добавляет кнопку "скачать видео" на пине после нажатия на три точки.
-------------------------------------------------------------------------------
ENG:
This extension (PVD) lets you download videos from Pinterest. Normally, videos can't be downloaded from the site. I used to rely on various third-party sites to download videos from Pinterest, but now I use my own extension 😜

Sometimes it doesn't download on the first try — you need to wait 15 seconds or just reload the site. I might fix this if I figure out how.

The extension adds a "Download Video" button to a pin after you click the three dots.
