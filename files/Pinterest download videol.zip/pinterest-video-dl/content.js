// ============================================
// content.js — ФИНАЛЬНАЯ ВЕРСИЯ
// ============================================

console.log('PVD: content.js загружен');

// Кэш: pinId → mp4
const mp4Cache = new Map();

function getCurrentPinId() {
    const m = location.pathname.match(/\/pin\/(\d+)/);
    return m ? m[1] : null;
}

function getVideoSignature() {
    const all = document.querySelectorAll('[data-video-signature]');
    for (const el of all) {
        if (el.offsetParent !== null) return el.getAttribute('data-video-signature');
    }
    return all.length ? all[0].getAttribute('data-video-signature') : null;
}

function findMp4Once() {
    const sig = getVideoSignature();
    if (!sig) return null;

    const prefix6 = sig.substring(0, 6).toLowerCase();
    const candidates = [];

    document.querySelectorAll('script').forEach((s) => {
        const txt = s.textContent || '';
        if (!txt.includes('.mp4')) return;

        const mp4s = [...txt.matchAll(/https:\/\/v1\.pinimg\.com\/videos\/[^"'\s\\]+\.mp4[^"'\s\\]*/g)];
        for (const m of mp4s) {
            if (m[0].toLowerCase().includes(prefix6)) {
                candidates.push(m[0]);
            }
        }
    });

    if (!candidates.length) return null;

    candidates.sort((a, b) => {
        const ra = parseInt((a.match(/_(\d+)w\.mp4/) || [0, 0])[1]) || 0;
        const rb = parseInt((b.match(/_(\d+)w\.mp4/) || [0, 0])[1]) || 0;
        return rb - ra;
    });
    return candidates[0];
}

async function downloadCurrentVideo() {
    const pinId = getCurrentPinId();
    console.log('PVD: старт поиска mp4 для пина', pinId);

    if (pinId && mp4Cache.has(pinId)) {
        const cached = mp4Cache.get(pinId);
        console.log('PVD: mp4 из кэша:', cached);
        sendDownload(cached);
        return;
    }

    const status = showStatus('Ищу видео...');

    for (let i = 0; i < 75; i++) {
        const url = findMp4Once();
        if (url) {
            console.log('PVD: нашёл mp4:', url);
            if (pinId) mp4Cache.set(pinId, url);
            status.remove();
            sendDownload(url);
            return;
        }

        if (i % 5 === 0 && i > 0) {
            status.update(`Ищу видео... (${(i * 0.2).toFixed(1)} с)`);
        }

        await new Promise(r => setTimeout(r, 200));
    }

    status.remove();
    if (confirm('Не удалось найти видео. Перезагрузить страницу?')) {
        location.reload();
    }
}

function sendDownload(url) {
    chrome.runtime.sendMessage({ action: 'download', url: url }, (resp) => {
        if (chrome.runtime.lastError) {
            console.error('PVD: ошибка', chrome.runtime.lastError.message);
        } else {
            console.log('PVD: ответ', resp);
        }
    });
}

function showStatus(text) {
    const el = document.createElement('div');
    el.id = 'pvd-status';
    el.style.cssText = 'position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%); background: #111; color: #fff; padding: 12px 20px; border-radius: 12px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; font-size: 14px; font-weight: 600; z-index: 99999; box-shadow: 0 4px 16px rgba(0,0,0,0.3);';
    el.innerText = text;
    document.body.appendChild(el);
    return {
        update: (t) => { el.innerText = t; },
        remove: () => { el.remove(); }
    };
}

function makeButton(label, onClick) {
    const btn = document.createElement('div');
    btn.className = 'pvd-menu-item';
    btn.setAttribute('role', 'button');
    btn.setAttribute('tabindex', '0');
    btn.innerText = label;
    btn.style.cssText = 'display: flex; align-items: center; width: 100%; min-height: 48px; padding: 8px 16px; box-sizing: border-box; cursor: pointer; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; font-size: 16px; font-weight: 600; color: inherit; border-radius: 8px;';
    const handler = (e) => {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        onClick();
    };
    btn.addEventListener('click', handler, true);
    btn.addEventListener('mousedown', (e) => e.stopPropagation(), true);
    return btn;
}

function processMenu() {
    document.querySelectorAll('button, div, span').forEach((el) => {
        const t = (el.innerText || '').replace(/\s+/g, ' ').trim();
        if (t !== 'Скачать изображение' && t !== 'Download image') return;
        if (el.offsetParent === null) return;
        if (el.dataset.pvdReplaced === '1') return;
        if (!getVideoSignature()) return;

        el.dataset.pvdReplaced = '1';

        const clickable =
            el.closest('button') ||
            el.closest('[role="button"]') ||
            el.closest('[role="menuitem"]') ||
            el;

        const ourBtn = makeButton('Скачать видео', downloadCurrentVideo);
        clickable.parentNode.replaceChild(ourBtn, clickable);
        console.log('PVD: кнопка подменена');
    });
}

let lastPinId = null;
function onPinChange() {
    const currentPinId = getCurrentPinId();
    if (currentPinId === lastPinId) return;
    lastPinId = currentPinId;
    console.log('PVD: пин изменился на', currentPinId);

    document.querySelectorAll('[data-pvd-replaced="1"]').forEach((el) => {
        delete el.dataset.pvdReplaced;
    });
    document.querySelectorAll('.pvd-menu-item').forEach((el) => el.remove());
}

const origPushState = history.pushState;
history.pushState = function () {
    origPushState.apply(this, arguments);
    setTimeout(onPinChange, 100);
};
const origReplaceState = history.replaceState;
history.replaceState = function () {
    origReplaceState.apply(this, arguments);
    setTimeout(onPinChange, 100);
};
window.addEventListener('popstate', () => setTimeout(onPinChange, 100));

setInterval(onPinChange, 500);

new MutationObserver(processMenu).observe(document.body, {
    childList: true, subtree: true,
    attributes: true, attributeFilter: ['style', 'class']
});
setInterval(processMenu, 500);