console.log('PVD: background.js запущен');

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'download' && request.url) {
        chrome.downloads.download({
            url: request.url,
            filename: 'pinterest_video_' + Date.now() + '.mp4',
            saveAs: false
        }, (downloadId) => {
            if (chrome.runtime.lastError) {
                console.error('PVD BG: ошибка', chrome.runtime.lastError.message);
                sendResponse({ success: false, error: chrome.runtime.lastError.message });
            } else {
                console.log('PVD BG: скачивание запущено, id=', downloadId);
                sendResponse({ success: true, downloadId });
            }
        });
        return true;
    }
});